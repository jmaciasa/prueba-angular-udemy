/*
    ===== Código de TypeScript =====
*/

let nombre: string = 'Strider';
let hp: number | string = 95;
let estaVivo: boolean = true;

hp = 'FULL';


console.log( nombre, hp );


